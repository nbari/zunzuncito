"""Zunzuncito

micro-framework for creating REST API's

"""
from zunzuncito.version import __version__
from zunzuncito.zunzun import ZunZun
